Visitor faction emblems — 768 x 768 transparent PNGs
Blue: neurotechnology, xenoengineering, exploration
Green: nature, resilience, physical growth
Purple: death, sacrifice, occult life manipulation
Red: warfare, aggression and ballistic force
Yellow: technological order, fortification and protection
Themes are inferred from your cards, not formal faction-lore descriptions.
