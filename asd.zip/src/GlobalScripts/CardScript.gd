extends Node

const text_icons = {
	"{B}": "res://assets/card-components/Factions/Blue.png",
	"{G}": "res://assets/card-components/Factions/Green.png",
	"{P}": "res://assets/card-components/Factions/Purple.png",
	"{R}": "res://assets/card-components/Factions/Red.png",
	"{Y}": "res://assets/card-components/Factions/Yellow.png",
#	"{Use}": "res://assets/card-components/use-icon-black.png",
	"{damage}": "res://assets/card-components/attack-white.png",
	"{shield}": "res://assets/card-components/shield-white.png",
	"{0}": "res://assets/card-components/numbers/Colorless/0.png",
	"{1}": "res://assets/card-components/numbers/Colorless/1.png",
	"{2}": "res://assets/card-components/numbers/Colorless/2.png",
	"{3}": "res://assets/card-components/numbers/Colorless/3.png",
	"{4}": "res://assets/card-components/numbers/Colorless/4.png",
	"{5}": "res://assets/card-components/numbers/Colorless/5.png",
	"{6}": "res://assets/card-components/numbers/Colorless/6.png",
	"{7}": "res://assets/card-components/numbers/Colorless/7.png",
	"{8}": "res://assets/card-components/numbers/Colorless/8.png",
	"{9}": "res://assets/card-components/numbers/Colorless/9.png",
	"{X}": "res://assets/card-components/numbers/Colorless/X.png",
}

const combat_ability_hints = {
	"Evasive": "Can only be blocked by evasive units.",
	"Blitz": "Can attack and use abilities the turn its played.",
	"Vigilance": "Attacking doesn't exhaust it.",
	"Deadly": "Damage it deals kills the target.",
	"Drain": "Gains life equal to the damage dealt.",
	"Decay": "Loses 1 attack, 1 health, and 1 max health at the start of your turn.",
	"Trample": "Deals excess combat damage to the player",
	"Deploying": "Can't attack.",
	"Defender": "Can't attack.",
}

func get_card_image(set_name, card_name):
	return load("res://assets/card-images/"+set_name+"/"+card_name+".png")

func get_type_icon(type):
	return load ("res://assets/card-components/Types/"+type+".png")

func get_placeholder_image(type):
	return load("res://assets/card-images/placeholders/"+type+".png")

func to_knowledge_string(knowledge):
	match knowledge:
		GS.Types.Knowledge.BLUE:
			return "B"
		GS.Types.Knowledge.GREEN:
			return "G"
		GS.Types.Knowledge.RED:
			return "R"
		GS.Types.Knowledge.PURPLE:
			return "P"
		GS.Types.Knowledge.YELLOW:
			return "Y"
	return ""

func to_knowledge_color(knowledge):
	if knowledge:
		match knowledge[0].get_knowledge():
			GS.Types.Knowledge.BLUE:
				return Color.NAVY_BLUE
			GS.Types.Knowledge.GREEN:
				return Color.DARK_GREEN
			GS.Types.Knowledge.RED:
				return Color.DARK_RED
			GS.Types.Knowledge.PURPLE:
				return Color.REBECCA_PURPLE
			GS.Types.Knowledge.YELLOW:
				return Color.DARK_GOLDENROD
	return Color.DIM_GRAY

func to_knowledge_type(knowledge):
	match knowledge:
		"B":
			return GS.Types.Knowledge.BLUE
		"G":
			return GS.Types.Knowledge.GREEN
		"R":
			return GS.Types.Knowledge.RED
		"P":
			return GS.Types.Knowledge.PURPLE
		"Y":
			return GS.Types.Knowledge.YELLOW
	return GS.Types.Knowledge.NONE

func to_knowledge_string_with_count(knowledge):
	var s = ""
	for knw in knowledge:
		for i in knw.get_count():
			s += to_knowledge_string(knw.get_knowledge())
	return s

func to_knowledge_string_no_count(knowledge):
	var s = ""
	for knw in knowledge:
		s += to_knowledge_string(knw.get_knowledge())
	return s

func to_array_string(arr, sep = " "):
	var res = ""
	for s in arr:
		res += str(s) + sep
	return res

func position_in_bounds(size, pos):
		return Vector2(min(max(0, pos.x), 1820-size.x), min(max(0, pos.y), 930-size.y))

func compare_cost_name_cardP(a, b):
	var a_cost = str(a.get_cost()).strip_edges()
	var b_cost = str(b.get_cost()).strip_edges()
	var a_numeric = a_cost.is_valid_int() or a_cost.is_empty()
	var b_numeric = b_cost.is_valid_int() or b_cost.is_empty()
	if a_numeric != b_numeric:
		return a_numeric
	if a_numeric:
		if a_cost.to_int() != b_cost.to_int():
			return a_cost.to_int() < b_cost.to_int()
	else:
		var comparison = a_cost.naturalnocasecmp_to(b_cost)
		if comparison != 0:
			return comparison < 0
	var name_order = a.get_name().naturalnocasecmp_to(b.get_name())
	if name_order != 0:
		return name_order < 0
	return a.get_set().naturalnocasecmp_to(b.get_set()) < 0

func compare_color_cost_name_cardP(a, b):
	var a_c = a.get_knowledgeCost()
	var b_c = b.get_knowledgeCost()
	match to_knowledge_string_no_count(a_c).casecmp_to(to_knowledge_string_no_count(b_c)):
		-1: return true
		0: return compare_cost_name_cardP(a, b)
		1: return false

func change_stylebox_override(field, node, fun):
		var image_box = node.get_theme_stylebox(field).duplicate()
		fun.call(image_box)
		node.add_theme_stylebox_override(field, image_box)

func load_card_image_and_type(c):
	change_stylebox_override("panel", c.find_child("CardImage"),
	func(image_box):
		var image = get_card_image(c.card.get_set(),c.card.get_name())
		var type
		if c.card.get_types()[0] == "Spell" and c.card.get_subtypes():
			type = c.card.get_subtypes()[0]
		else:
			type = c.card.get_types()[0]
		if image:
			image_box.set_modulate(Color.WHITE)
			image_box.set_texture(image)
		else:
			image_box.set_texture(get_placeholder_image(type))
			image_box.set_modulate(Color.GRAY)
		c.find_child("TypeIcon").set_texture(get_type_icon(type)))


func setup_card(n, card=null):
	if card:
		n.card = card
		n.find_child("Contents").show()
		CS.load_card_image_and_type(n)
		n.find_child("CostArea").update(card.get_cost(), card.get_knowledgeCost())
		n.find_child("Name").set_text(card.get_name())
		n.find_child("DepletePanel").set_visible(card.get_depleted())
		CS.change_stylebox_override("normal", n.find_child("Name"), func(b): b.set_modulate(to_knowledge_color(card.get_knowledgeCost())))
		var ability_text = ""
		var combat = card.get_combat()
		if combat:
			n.find_child("Stats").set_visible(true)
			var stats_text = ""
			if combat.get_attack():
				n.find_child("Attack").set_text(str(combat.get_attack()))
			else:
				n.find_child("Attack").set_text("0")
			n.find_child("Shield").set_visible(combat.get_shield() != 0)
			if combat.get_shield():
				n.find_child("Shield").set_text(str(combat.get_shield()))
			else:
				n.find_child("Shield").set_visible(false)
			if combat.get_health():
				n.find_child("Health").set_text(str(combat.get_health()))
			else:
				n.find_child("Health").set_text("0")
			if combat.get_deploying() and !(combat.get_combatAbilities() and combat.get_combatAbilities().has("Blitz")):
				ability_text += "Can't Attack\n"
			if combat.get_combatAbilities():
				var abilities = combat.get_combatAbilities().map(func(s): return "[hint="+combat_ability_hints[s]+"]"+s+"[/hint]")
				ability_text += to_array_string(abilities, ", ") + "\n"
		else:
			n.find_child("Stats").set_visible(false)
		ability_text += card.get_description()
		if n.find_child("Ability"):
			if ability_text != "":
				n.find_child("AbilityPanel").set_visible(true)
				n.find_child("Ability").set_text_custom(ability_text, card.get_name())
				CS.change_stylebox_override("panel", n.find_child("AbilityPanel"), func(b): b.set_bg_color(to_knowledge_color(card.get_knowledgeCost())-Color(0,0,0,0.4)))
			else:
				n.find_child("AbilityPanel").set_visible(false)
	else:
		CS.change_stylebox_override("panel", n.find_child("CardImage"), func(i): i.set_texture(load(GS.card_back_path)))
		n.find_child("Contents").set_visible(false)

func sanitize_card_name(name):
	return name.replace(" ","").replace(".","").replace("-","")

func read_deck_file(path):
	var file = FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {"error": "Could not open deck: " + error_string(FileAccess.get_open_error())}
	var deck_name = file.get_line().strip_edges()
	if deck_name.is_empty():
		file.close()
		return {"error": "The deck must have a name on the first line."}
	var entries = []
	var lines = []
	var counts = {}
	var line_number = 1
	while not file.eof_reached():
		var line = file.get_line().strip_edges()
		line_number += 1
		if line.is_empty():
			continue
		var separator = line.find(";")
		var dot = line.find(".", separator + 1)
		var count_text = line.substr(0, separator)
		if separator <= 0 or dot <= separator + 1 or dot >= line.length() - 1 or not count_text.is_valid_int():
			file.close()
			return {"error": "Invalid deck entry on line %d." % line_number}
		var count = count_text.to_int()
		var set_name = line.substr(separator + 1, dot - separator - 1)
		var card_name = line.substr(dot + 1)
		var key = set_name + "." + card_name
		counts[key] = counts.get(key, 0) + count
		if count < 1 or counts[key] > 3:
			file.close()
			return {"error": "Deck entries must contain one to three copies per card (line %d)." % line_number}
		entries.append({"count": count, "set": set_name, "card": card_name})
		lines.append(str(count) + ";" + key)
	file.close()
	return {"name": deck_name, "entries": entries, "lines": lines}

func show_error(message):
	if not is_inside_tree() or get_tree().current_scene == null:
		return
	var dialog = AcceptDialog.new()
	dialog.title = "Unable to complete action"
	dialog.dialog_text = message
	get_tree().current_scene.add_child(dialog)
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered()
